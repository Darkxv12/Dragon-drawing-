package com.tradelock

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class GuardService : AccessibilityService() {
    private var lastToast = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        Keep.startKeepAlive(this)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        if (pkg == packageName) return
        val open = Rules.isOpen(this)

        // 1) Block kiye hue apps window ke bahar: Home + background se kill
        if (!open && pkg in Rules.blockedPackages(this)) {
            kick("Trading time nahi hai", pkg)
            return
        }

        // 2) Browser me block kiya hua website window ke bahar
        val urlId = Rules.BROWSERS[pkg]
        if (urlId != null) {
            if (open) return
            val root = rootInActiveWindow ?: return
            val url = root.findAccessibilityNodeInfosByViewId(urlId)
                .firstOrNull()?.text?.toString()?.lowercase() ?: return
            if (Rules.blockedWords(this).any { it.isNotBlank() && url.contains(it) }) {
                kick("Trading time nahi hai", null)
            }
            return
        }

        // 3) Protect mode: Settings/uninstall screens par TradeLock dikhe to Home
        if (Rules.protect(this) && pkg in Rules.PROTECTED_PKGS) {
            val root = rootInActiveWindow ?: return
            if (containsText(root, "TradeLock", 0)) kick("TradeLock ko chhedna allowed nahi", null)
        }
    }

    private fun kick(msg: String, killPkg: String?) {
        performGlobalAction(GLOBAL_ACTION_HOME)
        val now = System.currentTimeMillis()
        if (now - lastToast > 3000) {
            lastToast = now
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
        if (killPkg != null) {
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    am.killBackgroundProcesses(killPkg)
                } catch (ex: Exception) {
                }
            }, 600)
        }
    }

    private fun containsText(n: AccessibilityNodeInfo?, s: String, depth: Int): Boolean {
        if (n == null || depth > 25) return false
        if (n.text?.toString()?.contains(s, true) == true) return true
        if (n.contentDescription?.toString()?.contains(s, true) == true) return true
        for (i in 0 until n.childCount) {
            if (containsText(n.getChild(i), s, depth + 1)) return true
        }
        return false
    }

    override fun onInterrupt() {}
}
