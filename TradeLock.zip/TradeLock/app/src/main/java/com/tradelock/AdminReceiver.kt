package com.tradelock

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
