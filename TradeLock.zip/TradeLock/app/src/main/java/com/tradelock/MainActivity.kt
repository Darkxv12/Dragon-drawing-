package com.tradelock

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        Keep.startKeepAlive(this)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun render() {
        val dpm = getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(this, AdminReceiver::class.java)
        val pwr = getSystemService(PowerManager::class.java)

        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(40, 56, 40, 56)
        scroll.addView(col)

        fun title(t: String) {
            val v = TextView(this)
            v.text = t
            v.textSize = 26f
            v.setTextColor(Color.BLACK)
            v.setPadding(0, 0, 0, 16)
            col.addView(v)
        }
        fun info(t: String) {
            val v = TextView(this)
            v.text = t
            v.textSize = 16f
            v.setTextColor(Color.DKGRAY)
            v.setPadding(0, 8, 0, 8)
            col.addView(v)
        }
        fun row(label: String, ok: Boolean) {
            val v = TextView(this)
            v.text = (if (ok) "✅  " else "❌  ") + label
            v.textSize = 16f
            v.setTextColor(Color.BLACK)
            v.setPadding(0, 8, 0, 8)
            col.addView(v)
        }
        fun btn(t: String, f: () -> Unit) {
            val v = Button(this)
            v.text = t
            v.isAllCaps = false
            v.setOnClickListener { f() }
            col.addView(v)
        }

        val open = Rules.isOpen(this)
        title("TradeLock")
        info("Trading window: ${Rules.fmt(Rules.startMin(this))} – ${Rules.fmt(Rules.endMin(this))}")
        info(if (open) "Abhi: KHULA hai" else "Abhi: BAND hai")
        info("Blocked apps: ${Rules.blockedPackages(this).size}   |   Websites: ${Rules.blockedWords(this).size}")

        row("Device Admin", dpm.isAdminActive(admin))
        row("Accessibility guard", Keep.guardEnabled(this))
        row("Auto date & time", Rules.clockIsTrusted(this))
        row("Battery unrestricted", pwr.isIgnoringBatteryOptimizations(packageName))
        row("Protect mode (uninstall/settings lock)", Rules.protect(this))
        row("Auto re-enable (adb permission)", Keep.hasSecure(this))

        btn("1. Device Admin ON") {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
            startActivity(i)
        }
        btn("2. Accessibility guard ON") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("3. Battery: Unrestricted karo") {
            try {
                val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                i.data = Uri.parse("package:$packageName")
                startActivity(i)
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        btn("Block karne wale apps chuno") { pickApps() }
        btn("Websites / keywords") { editWords() }
        btn("Trading window badlo (AM/PM)") { pickWindow() }

        if (Rules.protect(this)) {
            btn("Protect mode OFF (mahine me ek baar)") {
                toast(Rules.tryDisableProtect(this))
                render()
            }
        } else {
            btn("Protect mode ON") {
                AlertDialog.Builder(this)
                    .setTitle("Protect mode ON?")
                    .setMessage("ON ke baad Settings me TradeLock band ho jayega aur uninstall nahi hoga. OFF karna mahine me sirf ek baar.")
                    .setPositiveButton("ON") { _, _ ->
                        Rules.setProtect(this, true)
                        render()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            if (dpm.isAdminActive(admin)) {
                btn("Device Admin band karo (testing)") {
                    dpm.removeActiveAdmin(admin)
                    render()
                }
            }
        }

        setContentView(scroll)
    }

    private fun pickWindow() {
        val s0 = Rules.startMin(this)
        val e0 = Rules.endMin(this)
        val startDlg = TimePickerDialog(this, { _, h, m ->
            val s = h * 60 + m
            val endDlg = TimePickerDialog(this, { _, h2, m2 ->
                toast(Rules.tryEditWindow(this, s, h2 * 60 + m2))
                render()
            }, e0 / 60, e0 % 60, false)
            endDlg.setTitle("Window END time")
            endDlg.show()
        }, s0 / 60, s0 % 60, false)
        startDlg.setTitle("Window START time")
        startDlg.show()
    }

    private fun pickApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val current = Rules.blockedPackages(this)
        val checked = BooleanArray(apps.size) { apps[it].first in current }
        val names = apps.map { it.second }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Block karne wale apps")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Save") { _, _ ->
                val launcherPkgs = apps.map { it.first }.toSet()
                val chosen = HashSet<String>()
                for (i in apps.indices) if (checked[i]) chosen.add(apps[i].first)
                for (p in current) if (p !in launcherPkgs) chosen.add(p)
                toast(Rules.saveSet(this, "pkgs", current, chosen))
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun editWords() {
        val cur = Rules.blockedWords(this)
        val et = EditText(this)
        et.setText(cur.joinToString(", "))
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        AlertDialog.Builder(this)
            .setTitle("Website keywords (comma se)")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val n = et.text.toString().split(",")
                    .map { it.trim().lowercase() }
                    .filter { it.isNotEmpty() }
                    .toSet()
                toast(Rules.saveSet(this, "words", cur, n))
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
