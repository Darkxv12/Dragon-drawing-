package com.tradelock

import android.content.Context
import android.provider.Settings
import java.time.LocalTime
import java.time.YearMonth

object Rules {
    val DEFAULT_PKGS = setOf(
        "com.metaquotes.metatrader5",
        "com.metaquotes.metatrader4",
        "com.exness.android.pt"
    )
    val DEFAULT_WORDS = setOf("exness", "metatrader", "mql5")

    // Browser -> URL bar ka view id
    val BROWSERS = mapOf(
        "com.android.chrome" to "com.android.chrome:id/url_bar",
        "com.brave.browser" to "com.brave.browser:id/url_bar",
        "com.microsoft.emmx" to "com.microsoft.emmx:id/url_bar",
        "com.sec.android.app.sbrowser" to "com.sec.android.app.sbrowser:id/location_bar_edit_text",
        "org.mozilla.firefox" to "org.mozilla.firefox:id/url_bar_title"
    )

    // Protect mode ON ho to in screens par "TradeLock" dikhte hi Home
    val PROTECTED_PKGS = setOf(
        "com.android.settings",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.google.android.permissioncontroller",
        "com.android.vending"
    )

    private fun p(c: Context) = c.getSharedPreferences("rules", Context.MODE_PRIVATE)
    private fun month() = YearMonth.now().toString()

    fun blockedPackages(c: Context): Set<String> = p(c).getStringSet("pkgs", DEFAULT_PKGS) ?: DEFAULT_PKGS
    fun blockedWords(c: Context): Set<String> = p(c).getStringSet("words", DEFAULT_WORDS) ?: DEFAULT_WORDS

    fun startMin(c: Context) = p(c).getInt("start", 18 * 60 + 30) // 6:30 PM
    fun endMin(c: Context) = p(c).getInt("end", 19 * 60 + 45)     // 7:45 PM

    fun fmt(m: Int): String {
        val h = m / 60
        val mm = m % 60
        val ap = if (h < 12) "AM" else "PM"
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "%d:%02d %s".format(h12, mm, ap)
    }

    fun clockIsTrusted(c: Context): Boolean {
        val r = c.contentResolver
        return Settings.Global.getInt(r, Settings.Global.AUTO_TIME, 0) == 1 &&
            Settings.Global.getInt(r, Settings.Global.AUTO_TIME_ZONE, 0) == 1
    }

    fun isOpen(c: Context): Boolean {
        if (!clockIsTrusted(c)) return false
        val n = LocalTime.now()
        val m = n.hour * 60 + n.minute
        return m >= startMin(c) && m < endMin(c)
    }

    fun protect(c: Context) = p(c).getBoolean("protect", false)
    fun setProtect(c: Context, on: Boolean) { p(c).edit().putBoolean("protect", on).apply() }

    // "Dheel dene wale" changes (kuch hatana, window badhana, protect OFF) mahine me sirf ek baar
    fun loosenAllowed(c: Context) = p(c).getString("lastLoosen", "") != month()
    private fun markLoosen(c: Context) { p(c).edit().putString("lastLoosen", month()).apply() }

    fun tryDisableProtect(c: Context): String {
        if (!loosenAllowed(c)) return "Is mahine ek baar badal chuke ho. Agle mahine try karna."
        markLoosen(c)
        setProtect(c, false)
        return "Protect mode OFF."
    }

    fun tryEditWindow(c: Context, s: Int, e: Int): String {
        if (e <= s) return "End time start ke baad hona chahiye."
        val shrink = s >= startMin(c) && e <= endMin(c)
        if (!shrink) {
            if (!loosenAllowed(c)) return "Is mahine window badal chuke ho. Agle mahine try karna."
            markLoosen(c)
        }
        p(c).edit().putInt("start", s).putInt("end", e).apply()
        return "Saved."
    }

    /** Naya add karna hamesha allowed. Hatana mahine me ek baar. */
    fun saveSet(c: Context, key: String, old: Set<String>, new: Set<String>): String {
        val result = HashSet(new)
        val removed = old - new
        var msg = "Saved."
        if (removed.isNotEmpty()) {
            if (loosenAllowed(c)) {
                markLoosen(c)
            } else {
                result.addAll(removed)
                msg = "Hatana is mahine allowed nahi. Sirf naye add hue."
            }
        }
        p(c).edit().putStringSet(key, result).apply()
        return msg
    }
}
