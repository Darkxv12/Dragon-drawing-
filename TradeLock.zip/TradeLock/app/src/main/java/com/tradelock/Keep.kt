package com.tradelock

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings

object Keep {
    const val CHANNEL = "tradelock"

    private fun flat(c: Context) = ComponentName(c, GuardService::class.java).flattenToString()
    private fun short(c: Context) = ComponentName(c, GuardService::class.java).flattenToShortString()

    fun guardEnabled(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.split(":").any { it.equals(flat(c), true) || it.equals(short(c), true) }
    }

    /** Sirf tab kaam karta hai jab WRITE_SECURE_SETTINGS (adb se) di gayi ho. */
    fun tryReEnable(c: Context) {
        try {
            if (guardEnabled(c)) return
            if (c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") != PackageManager.PERMISSION_GRANTED) return
            val cur = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            val next = if (cur.isEmpty()) flat(c) else cur + ":" + flat(c)
            Settings.Secure.putString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, next)
            Settings.Secure.putInt(c.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
        } catch (e: Exception) {
        }
    }

    fun hasSecure(c: Context) =
        c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    fun startKeepAlive(c: Context) {
        try {
            c.startForegroundService(Intent(c, KeepAliveService::class.java))
        } catch (e: Exception) {
        }
    }
}
