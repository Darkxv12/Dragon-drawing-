plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.tradelock"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.tradelock"
        minSdk = 26
        targetSdk = 33
        versionCode = 2
        versionName = "2.0"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("tradelock.keystore")
            storeType = "pkcs12"
            storePassword = "tradelock"
            keyAlias = "tradelock"
            keyPassword = "tradelock"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
